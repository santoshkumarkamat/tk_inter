from tkinter import * 
window = Tk()
window.title("Welocome to Whether API")
l1=Label(window,text="KNOW ABOUT WHEATHER",bg="blue",fg="red",width=50)
#li.pack()
#l1.grid(row=0,column=6)
l1.place(x=50,y=150)
window.mainloop()
