from tkinter import *
window = Tk() 
window.title("Welocome to Whether API")
window.minsize(width=400,height=200)
#window.maxsize(width=600,height=400)
window.mainloop()
