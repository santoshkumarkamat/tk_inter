from tkinter import *  

window = Tk() 
l1= PhotoImage(file="C:/Users/india/Desktop/tk12.png")
l2=Label(window,image=l1)
l2.pack()
window.mainloop()