from tkinter import * 
import requests
import json 

window = Tk()
window.title("Real Time Whether Forcasting") 
l1=PhotoImage(file='C:/Users/india/Desktop/whe1.png')
l2=Label(window,image=l1)
l2.pack()

v=StringVar()
def edtech():
    city=v.get() 
    url = "http://api.weatherapi.com/v1/current.json?key=0cfe372493524353bec190413222912&q="+city
    base = requests.get(url) 
    data = json.loads(base.content)
    l3.config(text='Temperture = ' + str(data['current']['temp_c']),bg="yellow", fg="green")
    l4.config(text='Location Detail :-' + str(data['location']),bg="yellow",fg="green")

e1 = Entry(window,width=30,bd=5,font=("Calibri",20),textvariable=v)
e1.place(x=350,y=250)

b1=Button(window,text='Submit',bg="green",fg="yellow",command=edtech)
b1.place(x=500,y=300)     

l3= Label(window,text="Get Here Temperture" , bg="green" , fg="yellow") 
l3.place(x=500, y=400)

l4= Label(window,text="City Details" , bg="green",fg="yellow")
l4.place(x=250,y=450)

window.mainloop()