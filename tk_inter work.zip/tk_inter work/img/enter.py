from tkinter import * 
window = Tk() 
e1 = Entry(window,width=30,bd=5,font=("Calibri",20))
e1.place(x=80,y=80)
b1=Button(window,text='Submit',bg="green",fg="yellow")
b1.place(x=250,y=150)
window.mainloop()