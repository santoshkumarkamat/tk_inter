from tkinter import * 
window = Tk()
l1= PhotoImage(file="C:/Users/india/Desktop/tk12.png")
l2=Label(window,image=l1)
l2.pack()
b1=Button(window,text='Submit',bg="green",fg="yellow")
b1.place(x=50,y=100)
b1.mainloop()